Built for windows.
Run the "Back-Track" application.